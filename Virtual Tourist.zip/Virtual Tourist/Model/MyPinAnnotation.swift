//
//  MyPinAnnotation.swift
//  Virtual Tourist
//
//  Created by Abdulrahman Al Shathry on 27/05/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import Foundation
import MapKit

class MyPinAnnotation: MKPointAnnotation {
    var pinObject: Pin!
}
