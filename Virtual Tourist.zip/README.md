# VirtualTourist
Virtual Tourist is an application that allows the user to drop pins in the map by long tapping in any place in the map. Then, the user can click on the pins to explore random images fetched from FlickerAPI using the pin coordinates.
