//
//  CollectionViewCell.swift
//  Virtual Tourist
//
//  Created by Abdulrahman Al Shathry on 02/06/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import Foundation
import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var ImageProduct: UIImageView!
    
    
}

